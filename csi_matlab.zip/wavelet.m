function wav=wavelet(s,lev)
wav=wden(s,'sqtwolog','s','sln',lev,'sym8');
