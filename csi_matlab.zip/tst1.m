close all
clear all
clc
count=0;
for j=4:4
    for i=4:4
        %batchdata=[];
        filename=['.\20180410\conv-' num2str(j) num2str(i)];
        %filename=['.\DeepFiData\deepfi-' num2str(j) num2str(i)];
        %filename=['.\20170727\deep-' num2str(j) num2str(i)];
        %filename='.\DATA_ACP\180330zx004Ap';
        if(exist(filename)==2)
            s=getbatchdatatest(filename,1,1401);
            %s=getphasetest(filename,200,500);
            %s=uint8(s);
            %s=getphasetest(filename,100,1600);
            %figure(2)
            %surfplot(s,1,30,300)
            %save(['raw' num2str(j) num2str(i)],'s') 
            %savepath=['G:\PyProject\Csi\resources\s' num2str(j) num2str(i) '.mat'];
            %save(savepath,'s');
            %csi=smoothed_csi(s(:,:,100));
            %name=num2str(count);
            %s=wavelet(abs(s),3);
%             temp=zeros(3,30,1400);
%             for ch=1:30
%                 temp(1,ch,:)=wavelet(squeeze(abs(s(1,ch,:))),3);
%                 temp(3,ch,:)=wavelet(squeeze(abs(s(2,ch,:))),3);
%                 temp(3,ch,:)=wavelet(squeeze(abs(s(3,ch,:))),3);
%             end
%             savepath=['.\DATA_DENOISING\test\' num2str(count) ];
%             save(savepath,'temp')
            %count=count+1;
            fprintf(1,'training data %s prepared\n', filename);
        end
        count=count+1;
    end
end