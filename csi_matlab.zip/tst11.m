clear
clc
%filename='./DATA_ACP/180330zx001Ap';
filename='./DeepFiData/deepfi-11';
s=getphasetest(filename,100,500);
s_sm=sliding(s);
% s_sm=sliding(s(:,:,400));
figure(2)
simg=uint8(s_sm);
imshow(simg)

