clc 
clear
load Signal_Filter
load wavelt
load csi_1
load csi_2

lev=5;
csi_butt=zeros(3,30,Num-500);
for ii=1:3
    for jj=1:30
        temp=filter(b,a,abs(squeeze(csi_1(ii,jj,:))'));
        csi_butt(ii,jj,:)=temp(500:Num-1)';
        temp=0;
    end
end

csi_wlt=zeros(3,30,Num);
for i=1:3
    for j=1:30
        x=abs(squeeze(csi_1(i,j,:)));
        xd=wden(x,'sqtwolog','s','sln',lev,'sym8');
        csi_wlt(i,j,:)=xd';
        x=0;xd=0;
    end
end
%%static
WIN=10;
coefn=zeros(3,30);
coefh=zeros(3,30);
for i=1:3
    for j=1:30
        temp1=0;temp2=0;count=0;
        for k=max(j-5,1):min(j+5,30)
            if j~=k
                %temp=temp+min(min(corrcoef(wavelt(i,j,:),wavelt(i,k,:))));
                temp1=temp1+min(min(corrcoef(wavelt(i,j,500:Num),wavelt(i,k,500:Num))));
                temp2=temp2+min(min(corrcoef(csi_butt(i,j,:),csi_butt(i,k,:))));
                count=count+1;
            end
        end
        coefh(i,j)=temp1/count;
        coefn(i,j)=temp2/count;
    end
end

coefgain=coefh-coefn;
%coefcell=cell(3,30);
%for i=1:3
%    for j=1:30
%        coefcell{i}{j}={[num2str(i) num2str(j)],coefgain(i,j)};
%    end
%end
for i=1:3
%    coefgain(i,:)=sort(coefgain(i,:),'descend');       
    plot(coefgain(i,:))
    hold on
    grid on
end
