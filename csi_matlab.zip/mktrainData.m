clear all
clc
N=1;M=2500;
%mkdir('D:\20180404\train');
cnt=0;
for row=2:4
    for col=1:4
        %mkdir('D:\csiimg\' num2str(row) num2str(col))
        dirname=['D:\20180415\train\' num2str(cnt)];
        %dirname='D:\csiimg_trible';
        if(~exist(dirname))
            mkdir(dirname)
        end
        filename1=['.\20180410\conv-' num2str(row) num2str(col)];
        count=getScaledbatch(filename1,dirname,2000);
        filename2=['.\20180410\conv-' num2str(row) num2str(col) '-1'];
        count1=getScaledbatch_s(filename2,dirname,1200,count);
        filename3=['.\20180410\conv-' num2str(row) num2str(col) '-2'];
        count2=getScaledbatch_s(filename3,dirname,1200,count1);
%         if(exist(filename)==2)
%             csi_trace = read_bf_file(filename);
%             NUMBER=numel(csi_trace);
%             %N=400;M=1200;
%             csi=zeros(3,30,NUMBER);
%             for i=1:NUMBER
%                 csi_entry = csi_trace{i};
%                 csientry = get_scaled_csi(csi_entry);
%                 perm = csi_entry.perm;
%                 for k=1:3
%                     if perm(k)==1
%                         csi(1,:,i)=csientry(1,perm(k),:);
%                     elseif perm(k)==2
%                         csi(2,:,i)=csientry(1,perm(k),:);
%                     elseif perm(k)==3
%                         csi(3,:,i)=csientry(1,perm(k),:);
%                     end
%                 end
%             end
%         end
%         tmp=abs(csi);
%         tmp=getScaledbatch(filename);
%         csi2img=zeros(NUMBER,30,3);
%         for i=1:3
%             for j=1:30
%                 csi2img(:,j,i)=tmp(i,j,:);
%             end
%         end
%         count=1;
%         while(count+29<NUMBER)
%             originimg=uint8(csi2img([count:count+29],:,:));
%             count=count+1;
%             picname=[dirname '\'  num2str(count) '.jpg'];
%             imwrite(originimg,picname)
%         end
        fprintf(1,'trainingdata %s prepared\n',filename1);
        cnt=cnt+1;
    end
end