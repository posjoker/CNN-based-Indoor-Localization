function rssi=rssi(x)
csi_trace = read_bf_file(x);
for i=1:1000
    csi_entry=csi_trace{i};
    rssi{i}=(csi_entry.rssi_b+csi_entry.rssi_c)/2;
end

    