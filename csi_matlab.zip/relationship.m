clear
clc
a=load('11');b=load('12');c=load('21');d=load('22');
a_=load('31');b_=load('32');c_=load('41');d_=load('42');
csi11=a.s;csi12=b.s;csi21=c.s;csi22=d.s;
csi31=a_.s;csi32=b_.s;csi41=c_.s;csi42=d_.s;
relation=[csi11 csi12;csi21 csi22]./[csi31 csi32;csi41 csi42];
r21=csi21./csi11;
r22=csi22./csi11;
