function cnt=getScaledbatch_s(filename,dirname,NUMBER,count)
if(exist(filename)==2)
    count1=1;
    csi_trace = read_bf_file(filename);
            %NUMBER=numel(csi_trace);
            %N=400;M=1200;
    csi=zeros(3,30,NUMBER);
            for i=1:NUMBER
                csi_entry = csi_trace{i};
                csientry = get_scaled_csi(csi_entry);
                perm = csi_entry.perm;
                for k=1:3
                    if perm(k)==1
                        csi(1,:,i)=csientry(1,perm(k),:);
                    elseif perm(k)==2
                        csi(2,:,i)=csientry(1,perm(k),:);
                    elseif perm(k)==3
                        csi(3,:,i)=csientry(1,perm(k),:);
                    end
                end
            end
        tmp=abs(csi);
        %tmp=getScaledbatch(filename);
        csi2img=zeros(NUMBER,30,3);
        for i=1:3
            for j=1:30
                csi2img(:,j,i)=tmp(i,j,:);
            end
        end
        %count=1;
        while(count1+29<NUMBER)
            originimg=uint8(csi2img([count1:count1+29],:,:));
            picname=[dirname '\'  num2str(count+count1-1) '.jpg'];
            imwrite(originimg,picname)
            count=count+1;
            count1=count1+1;
        end
end
cnt=count;