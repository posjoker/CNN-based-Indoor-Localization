function surfplot(s,antenna,channel,length)
    z=squeeze(s(antenna,1:channel,1:length));
    x=1:length;
    y=1:channel;
    surf(x,y,z)
    colormap(jet)
    colorbar
    shading interp