clc
clear

t=-1:0.01:1;
w0=50;
T=100;
g1=exp(-t.^2).*cos(w0.*t);
g2=exp(-t.^2).*cos(2*w0.*t);
subplot(1,2,1)
plot(t,g1)
subplot(1,2,2)
plot(t,g2)
