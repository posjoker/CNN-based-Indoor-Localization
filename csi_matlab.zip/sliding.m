function slide_csi=sliding(csi)
slide_csi=zeros(30,30,3);
m=1;
for i=1:30
    n=1;
    for j=i:30
        slide_csi(m,n,1)=csi(1,j);
        slide_csi(m,n,2)=csi(2,j);
        slide_csi(m,n,3)=csi(3,j);
        l=1;
        for k=1:i-1
            slide_csi(m,n+l,1)=csi(1,k);
            slide_csi(m,n+l,2)=csi(2,k);
            slide_csi(m,n+l,3)=csi(3,k);
            l=l+1;
        end
        n=n+1;
    end
    m=m+1;
end