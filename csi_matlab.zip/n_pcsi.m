function n=n_pcsi(x,y,m)
z1=pro_csi(x)
z2=pro_csi(y)
n=(z1{20}-z2{20})/(10*log(m/6))

