clc
clear all
close all
originimg=imread('lenna.png');
originimg=rgb2gray(originimg);
[ori_row,ori_col]=size(originimg);
%imshow(I(:,:,3))
sigma=1.6;  %sigma
N=7;
N_row=2*N+1;
OriImage_noise=imnoise(originimg,'gaussian'); %add noise

gausFilter=fspecial('gaussian',[N_row,N_row],sigma);  %matlab�Դ���˹ģ��
blur=imfilter(OriImage_noise,gausFilter,'conv');

H=[];      %���˹ģ��H
for i=1:N_row
    for j=1:N_row
        numerator=(i-N-1)^2+(j-N-1)^2;
        H(i,j)=exp(-numerator/(2*sigma^2))/(2*pi*sigma^2);
    end
end

H=H/sum(H(:));
desimg=zeros(ori_row,ori_col);
for i=1:ori_row
    for j=1:ori_col
        desimg(i,j)=OriImage_noise(i,j);
    end
end
        
temp=[];
for ai=N+1:ori_row-N-1
    for aj=N+1:ori_col-N-1
        temp=0;
        for bi=1:N_row
            for bj=1:N_row
                temp=temp+(desimg(ai+bi-N,aj+bj-N)*H(bi,bj));
            end
        end
        desimg(ai,aj)=temp;
    end
end

desimg=uint8(desimg);
subplot(2,2,1);imshow(originimg);title('ԭͼ');
subplot(2,2,2);imshow(OriImage_noise);title('����ͼ');
subplot(2,2,3);imshow(desimg);title('GaussFilter');
subplot(2,2,4);imshow(blur);title('template filter')
