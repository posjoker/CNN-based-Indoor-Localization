clear
clc
%%READ DATA
F_START=300;  %BEGIN OF THE STREAM
F_END=812;   %END OF THE STREAM
filename_1=input('filename_1');
filename_2=input('filename_2');
csi_trace_1=read_bf_file(filename_1);
csi_trace_2=read_bf_file(filename_2);
csi_1=zeros(3,30,F_END-F_START);
csi_2=zeros(3,30,F_END-F_START);
for i=(F_START+1):F_END
    csi_entry_1=csi_trace_1{i};
    csientry_1=get_scaled_csi(csi_entry_1);
    perm_1 = csi_entry_1.perm;
    for k=1:3
        if perm_1(k)==1
            csi_1(1,:,i-F_START)=csientry_1(1,perm_1(k),:); 
        elseif perm_1(k)==2
            csi_1(2,:,i-F_START)=csientry_1(1,perm_1(k),:);
        elseif perm_1(k)==3
            csi_1(3,:,i-F_START)=csientry_1(1,perm_1(k),:);
        end
    end
end
for i=(F_START+1):F_END
    csi_entry_2=csi_trace_2{i};
    csientry_2=get_scaled_csi(csi_entry_2);
    perm_2 = csi_entry_2.perm;
    for k=1:3
        if perm_2(k)==1
            csi_2(1,:,i-F_START)=csientry_2(1,perm_2(k),:); 
        elseif perm_2(k)==2
            csi_2(2,:,i-F_START)=csientry_2(1,perm_2(k),:);
        elseif perm_2(k)==3
            csi_2(3,:,i-F_START)=csientry_2(1,perm_2(k),:);
        end
    end
end

%%Draw
figure(1)
for j=1:30
    subplot(3,2,1)
    plot(abs(squeeze(csi_1(1,j,:))'))
    hold on
    subplot(3,2,2)
    plot(abs(squeeze(csi_2(1,j,:))'))
    hold on
    subplot(3,2,3)
    plot(abs(squeeze(csi_1(2,j,:))'))
    hold on
    subplot(3,2,4)
    plot(abs(squeeze(csi_2(2,j,:))'))
    hold on
    subplot(3,2,5)
    plot(abs(squeeze(csi_1(3,j,:))'))
    hold on
    subplot(3,2,6)
    plot(abs(squeeze(csi_2(3,j,:))'))
    hold on
end

%%Passband filtering
%%Buttord filter
Fs=F_END-F_START;
Num=F_END-F_START;
max_freq=80;
%min_freq=2;
hsr=Fs/2;
[b,a] = butter(6,max_freq/hsr,'low');
%[d,c] = butter(3,min_freq/hsr,'high');

%Wc=80*2/Fs;
%[b,a] = butter(6,Wc,'low');
%[b,a] = butter(4,Wc);
%figure(2)
%Signal_Filter=filter(b,a,abs(squeeze(csi_2(1,2,:))').^2);
%Signal_Filter1=filter(d,c,Signal_Filter);

Signal_Filter=zeros(3,30,Num);
for ii=1:3
    for jj=1:30
        temp=filter(b,a,abs(squeeze(csi_2(ii,jj,:))'));
        Signal_Filter(ii,jj,:)=temp';
        temp=0;
    end
end

figure(2)
title('ԭʼ�ź����ͨ�˲��źŶԱ�ͼ')
for count=1:3
    subplot(3,1,count)
    plot(abs(squeeze(Signal_Filter(count,2,:))'),'*r')
    hold on
    plot(abs(squeeze(csi_2(count,2,500:F_END-F_START-1))'),'b')
    grid on
end

%%Wavelet filtering
lev=5;
wavelt=zeros(3,30,Num);
for i=1:3
    for j=1:30
        x=abs(squeeze(csi_2(i,j,:)));
        xd=wden(x,'sqtwolog','s','sln',lev,'sym8');
        wavelt(i,j,:)=xd';
        x=0;xd=0;
    end
end


figure(3)
for count=1:3
    subplot(3,1,count)
    plot(abs(squeeze(wavelt(count,2,:))'),'*r')
    hold on
    plot(abs(squeeze(csi_2(count,2,:))'),'b')
    grid on
end

figure(4)
for i=1:3
    switch i
        case 1 
            j=1;
            subplot(3,2,j);
            plot(squeeze(Signal_Filter(i,:,:)))
            subplot(3,2,j+1)
            plot(squeeze(wavelt(i,:,:)))
        case 2 
            j=3;
            subplot(3,2,j);
            plot(squeeze(Signal_Filter(i,:,:)))
            subplot(3,2,j+1)
            plot(squeeze(wavelt(i,:,:)))
        case 3 
            j=5;
            subplot(3,2,j);
            plot(squeeze(Signal_Filter(i,:,:)))
            subplot(3,2,j+1)
            plot(squeeze(wavelt(i,:,:)))
    end
end
    

%%Correlation coefficient between two conditions
%coef=zeros(30,2,2);
%for i=1:30
%    coef(i,:,:)=corrcoef(abs(csi_1(1,i,:)),abs(csi_2(1,i,:)));
%end

%%Correlation coefficient between different channel

       