function batchdata=getbatchdatatest(filename,N,M)
%filename='.\phase-dynamic-165'
csi_trace = read_bf_file(filename);
csi=zeros(3,30,M-N);
batchdata=zeros(3,30,M-N);
%Ntx=1;
for i=(N+1):M
    csi_entry = csi_trace{i};
    csientry = get_scaled_csi(csi_entry);
    perm = csi_entry.perm;
    for k=1:3
        if perm(k)==1
            csi(1,:,i-N)=csientry(1,perm(k),:);
        elseif perm(k)==2
            csi(2,:,i-N)=csientry(1,perm(k),:);
        elseif perm(k)==3
            csi(3,:,i-N)=csientry(1,perm(k),:);
        end
    end
    
end

%csi=abs(squezze(csi))
for i=1:3
    for j=1:30
        batchdata(i,j,:)=(squeeze(csi(i,j,:)));
    end
end

%batchdata=batchdata/max(max(max(batchdata)));