function batchdata=getbatchdata(filename,N,M)

csi_trace = read_bf_file(filename);
csi=zeros(3,30,M-N);

for i=(N+1):M
    csi_entry = csi_trace{i};
    csientry = get_scaled_csi(csi_entry);
%     csientry=csi_entry.csi;
    perm = csi_entry.perm;
%     rss(1,i-N)=csi_entry.rssi_a;
%     rss(2,i-N)=csi_entry.rssi_b;
%     rss(3,i-N)=csi_entry.rssi_c;
    for k=1:3
        if perm(k)==1
            csi(1,:,i-N)=csientry(1,perm(k),:); 
        elseif perm(k)==2
            csi(2,:,i-N)=csientry(1,perm(k),:);
        elseif perm(k)==3
            csi(3,:,i-N)=csientry(1,perm(k),:);
        end
    end

%��ͼ��ʱ��Ƶ��
%      subplot(1,2,1)
%      plot(db(abs(squeeze(csi(1,:,i-N)))),'r')
%      hold on
%      plot(db(abs(squeeze(csi(2,:,i-N)))),'b')
%      hold on 
%      plot(db(abs(squeeze(csi(3,:,i-N)))),'g')
%      xlabel('Subcarrier index');
%      ylabel('SNR [dB]');
end

% for i=(N+1):M
%     %for j=1:30
%        subplot(1,2,2)
%        plot(csi(1,15,i-N),'r*')
%        hold on
%     %end
% end

batchdata=db(abs(squeeze(csi(:,:,:))));