clc
clear all
filename='.\DATA_ACP\180330zx001A'
%filename='phase-static-165'
if(exist(filename)==2)
    s=getphasetest(filename,200,500);
  %  z=squeeze(s(1,:,1:1000));
   % x=1:1000;
    %y=1:30;
    %surf(x,y,z)
    %figure(2)
    %surfplot(s,1,30,1000)
    L=1000;Fs=1000;
    NFFT=2^5;
    s_fft=fft(squeeze(s(1,15,:)),NFFT)/L;
    f = Fs/2*linspace(0,1,NFFT/2+1); 
    
    figure(3)
    %plot(abs(s_fft))
    plot(f,2*abs(s_fft(1:NFFT/2+1)))  
end