clc
a=1
b=3
%syms x
%f1(x)=a*exp(log(b/a)*x)

y=rand(1,1000);
%ezplot(f1(x))
samples=a.*exp(log(b/a).*y)
%ft=zeros(100,1)
%for i=1:100
%    ft=f1(i)
%end
%plot(samples)

 hist(samples)
 x=1:0.01:3;
 y=1./(x.*log(b/a))
 plot(x,y)
 
 