function process(x,y,n,m)
[x1,y1,z1]=prssi(x)
[x2,y2,z2]=prssi(y)
for i=1:200
    d{i}=1*10^((z1{i}-z2{i})/(10*n))-m
end
a=1:10

for i=1:10
    a(i)=0
end

for i=1:200
   for j=1:10
       if abs(d{i})<=j&&abs(d{i})>j-1
           a(j)=a(j)+1
           j=j+1
           break
       else
           j=j+1
       end
   end
end

bar(a,0.2)
        