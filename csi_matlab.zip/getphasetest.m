function Cp=getphasetest(filename,N,M)
csi_trace = read_bf_file(filename);
csi=zeros(3,30,M-N);
%batchdata=zeros(3,30,M-N);
%Ntx=1;
for i=(N+1):M
    csi_entry = csi_trace{i};
    csientry = get_scaled_csi(csi_entry);
    perm = csi_entry.perm;
    for k=1:3
        if perm(k)==1
            csi(1,:,i-N)=csientry(1,perm(k),:);
        elseif perm(k)==2
            csi(2,:,i-N)=csientry(1,perm(k),:);
        elseif perm(k)==3
            csi(3,:,i-N)=csientry(1,perm(k),:);
        end
    end
    
end
Mp=zeros(3,30,M-N);
for i=1:3
    for j=1:30
        Mp(i,j,:)=angle(squeeze(csi(i,j,:)).');   %raw phase
    end
end
Tp=zeros(3,30,M-N);
Cp=zeros(3,30,M-N);
%diff=0;
Tp(1,1,:)=Mp(1,1,:);
Tp(2,1,:)=Mp(2,1,:);
Tp(3,1,:)=Mp(3,1,:);
for k=1:1:(M-N)
    for i=1:3
        diff=0;
        for j=2:30
            if  Mp(i,j,k)-Mp(i,j-1,k)>pi
                diff=diff+1;
            end
            Tp(i,j,k)=Mp(i,j,k)-diff*2*pi;
        end
    end 
end
k=zeros(1,3);b=zeros(1,3);

m1=-28:2:-2;m2=-1:2:27;m=[m1 m2 28];  %interval

%for i=1:3
%    k(i)=(Tp(30,i)-Tp(1,i))/56;
%    b(i)=sum(Tp(:,i))/30;
%end
for n=1:(M-N)
    for i=1:3
        k(i)=(Tp(i,30,n)-Tp(i,1,n))/56;
        b(i)=sum(Tp(i,:,n))/30;
        for j=1:30
            Cp(i,j,n)=Tp(i,j,n)-k(i)*m(j)-b(i);
        end
    end
end
for i=1:(M-N)
    %plot(m,Cp(2,:,i)*180/pi,'-d')
    %subplot(121)
    %polar(squeeze(angle(csi(1,15,i))),'*');
    %plot(squeeze(Cp(1,5,:)*180/(2*pi)));
    %polar(squeeze(angle(csi(1,15,i))),squeeze(abs(csi(1,15,i))),'.')
    subplot(122)
    polar(squeeze(Cp(1,1,i)),squeeze(abs(csi(1,1,i))),'*')
    hold on
end
%save Cp
    %z=squeeze(angle(csi(1,:,1:500))*180/pi);

%
%z=zeros(1,200);
%z=squeeze(Cp(1,15,1:200));
%x=[1:200];
%y=[-1:0.01:0.99];
%[X,Y]=meshgrid(x,y);
%[X,Y,Z]=meshgrid(x,y,z);
%surf(X,Z)
   % plot(squeeze(abs(csi(1,15,:))))
%for j=1:30
    %plot(squeeze(Cp(2,:,:)*180/pi));
%    hold on
%end
%[X,Y]=meshgrid(m,Cp(1,:,200));
%surf(X,Y)
%plot(squeeze(Cp(1,15,:)))
%plot(squeeze(angle(csi(1,15,:))*180/pi))
%xlabel('Subcarrier Index') 
%ylabel('Calibrated Phase')
%axis([-28,28,-5,5]) 
%legend('Antenna 1','Antenna 2','Antenna 3')
%grid on 
%hold on
%subplot(1,2,1)
%plot(m,Tp,'-d')
%xlabel('Subcarrier Index')
%ylabel('Ture Measured Phase')
%legend('Antenna 1','Antenna 2','Antenna 3')
%subplot(1,3,3)
%plot(angle(squeeze(csientry(1,:,:)).'),'-d')
%grid on
%hold on