clc 
clear

row=8;col=6;
filename=['.\DeepFiData\deepfi-' num2str(row) num2str(col)];
csi_trace = read_bf_file(filename);
%ts1=csi_trace{1}.timestamp_low;
%ts2=csi_trace{2}.timestamp_low;
M=400;N=1200;       %start and stop
numlength=numel(csi_trace);
timestamp_low=zeros(1,800);
for i=M:N
    timestamp_low(i-M+1)=csi_trace{i}.timestamp_low;
end
X=1:1:N-M;
Y=timestamp_low(1:800);
a=polyfit(X,Y,1);
y_=a(1)*X+a(2);
figure(1)
plot(X,y_)
hold on
plot(Y,'.')

m=zeros(1,800);
figure(2)
for j=1:800
    m(j)=timestamp_low(j+1)-timestamp_low(j);
end
plot(m)
    