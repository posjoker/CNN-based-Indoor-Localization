function[agc,rssi,csi]= pro(x)
csi_trace = read_bf_file(x);
for i=100:300
    csi_entry=csi_trace{i};
    rssi{i-99}=(csi_entry.rssi_b+csi_entry.rssi_c)/2;
    agc{i-99}=csi_entry.agc;
    csi{i-99}=get_scaled_csi(csi_entry);
end


%csi_entry = csi_trace{1};
%csi = get_scaled_csi(csi_entry);
% plot(db(abs(squeeze(csi(1,:,:)).')))
%legend('RX Antenna A', 'RX Antenna B', 'RX Antenna C', 'Location', 'SouthEast' );           
%xlabel('Subcarrier index');            
% ylabel('SNR [dB]');
