clear
clc
for i=2:2
    for j=2:2
        filename=['.\20180410\conv-' num2str(i) num2str(j) ];
        temp=getbatchdata(filename,100,1500);
        %temp=wavelet(temp,5);
        u8temp=uint8(temp);
    end
end
subplot(1,2,1)
plot(squeeze(u8temp(1,:,:)))
subplot(1,2,2)
plot(squeeze(temp(1,:,:)))
figure(2)
surfplot(u8temp,1,30,1400)