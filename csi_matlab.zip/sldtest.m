clc
clear 
N=1;M=2500;
%mkdir('D:\20180404\train');
cnt=0;
for row=1:8
    for col=1:6
        %mkdir('D:\csiimg\' num2str(row) num2str(col))
        dirname=['D:\20180425\data\train\' num2str(cnt)];
        %dirname='D:\csiimg_trible';
        if(~exist(dirname))
            mkdir(dirname)
        end
        %filename1=['.\20180410\conv-' num2str(row) num2str(col)];
        filename1=['.\data\deepfi-' num2str(row) num2str(col)];
        count=getSlide(filename1,dirname,700);
%         filename2=['.\20180410\conv-' num2str(row) num2str(col) '-1'];
%         count1=getSlide_1(filename2,dirname,1200,count);
%         filename3=['.\20180410\conv-' num2str(row) num2str(col) '-2'];
%         count2=getSlide_1(filename3,dirname,1200,count1);
         fprintf(1,'trainingdata %s prepared\n',filename1);
         cnt=cnt+1;
    end
end