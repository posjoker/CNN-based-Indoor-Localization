function pcsi= pro_csi(x)
csi_trace = read_bf_file(x);
for i=501:700
    csi_entry=csi_trace{i};
    %rssi{i-99}=(csi_entry.rssi_b+csi_entry.rssi_c)/2;
    agc(i-500)=csi_entry.agc;
    csi{i-500}=get_scaled_csi(csi_entry);
end
%ȡһ���������ߺ�һ����������
for i=1:200
    csie(i)=0
    for j=1:30
        csie(i)=csie(i)+(abs(csi{i}(2,3,j)))*((2.4+0.0015*j)/2.4223)/30
    end
end

for i=1:200
    pcsi{i}=csie(i)/sqrt(10^(agc(i)/10))
end
    