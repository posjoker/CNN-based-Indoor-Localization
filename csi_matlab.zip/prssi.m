function [rssi,agc,prssi]=prssi(x)
csi_trace = read_bf_file(x);
for i=501:700
    csi_entry=csi_trace{i}
    rssi{i-500}=(csi_entry.rssi_b+csi_entry.rssi_c)/2;
    agc{i-500}=csi_entry.agc;
end
for i=1:200
    prssi{i}=rssi{i}-44-agc{i}
end
