clc
clear
row=5;col=4;
filename=['.\DeepFiData\deepfi-' num2str(row) num2str(col)];
csi_trace = read_bf_file(filename);
N=400;M=1200;
csi=zeros(3,30,M-N);
for i=(N+1):M
    csi_entry = csi_trace{i};
    csientry = get_scaled_csi(csi_entry);
    perm = csi_entry.perm;
    for k=1:3
        if perm(k)==1
            csi(1,:,i-N)=csientry(1,perm(k),:);
        elseif perm(k)==2
            csi(2,:,i-N)=csientry(1,perm(k),:);
        elseif perm(k)==3
            csi(3,:,i-N)=csientry(1,perm(k),:);
        end
    end
end
tmp=abs(csi);
csi2img=zeros(800,30,3);
for i=1:3
    for j=1:30
        csi2img(:,j,i)=tmp(i,j,:);
    end
end

%csi2img=reshape(csi2img,800,30,3);
%sample=uint8(csi2img([301:330],:,:));
sample=uint8(csi2img([51:80],:,:));
originimg=rgb2gray(sample);
imshow(sample)



